import React from "react";
import { Pie } from "react-chartjs-2";
import {
  Chart as ChartJS,
  ArcElement,
  Tooltip,
  Legend,
} from "chart.js";

// Registering chart.js components
ChartJS.register(ArcElement, Tooltip, Legend);

const AppUsageChart = ({ className }) => {
  const data = {
    labels: ['Category A', 'Category B', 'Category C'],
    datasets: [
      {
        label: 'Usage Hours',
        data: [55.87, 34.39, 89.77],
        backgroundColor: ['#f87171', '#4ade80', '#60a5fa'],
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: true,
    plugins: {
      legend: {
        position: 'top',
        labels: { color: '#ffffff' },
      },
      tooltip: { enabled: true },
    },
  };

  return (
    <div className={`w-full h-[300px] max-w-[500px] mx-auto bg-[#C1C1C1] p-4 rounded-lg shadow-md ${className}`}>
      <h3 className="text-xl font-semibold text-[#3B3F70] mb-4">App Usage</h3>
      <Pie data={data} options={options} />
    </div>
  );
};

export default AppUsageChart;
