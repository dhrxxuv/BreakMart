import React from "react";

const AttendancePanel = () => (
  <div className="bg-[#C1C1C1] text-[#3B3F70] p-6 rounded-lg shadow-lg w-full">
    {/* Header */}
    <h3 className="text-xl font-bold mb-6 text-center md:text-left">Today's Attendance</h3>

    {/* Content */}
    <div className="flex flex-col md:flex-row justify-between items-center space-y-6 md:space-y-0">
      {/* Total Users */}
      <div className="flex-1 text-center">
        <div className="text-4xl font-bold">67</div>
        <p className="text-sm text-[#3B3F70]">Total Users</p>
      </div>

      {/* Attendance Stats */}
      <div className="flex flex-1 justify-around w-full space-x-4 md:space-x-6">
        {/* Present */}
        <div className="text-center">
          <div className="text-2xl font-semibold">34</div>
          <p className="text-sm text-[#3B3F70]">Present</p>
        </div>
        {/* Absent */}
        <div className="text-center">
          <div className="text-2xl font-semibold">19</div>
          <p className="text-sm text-[#3B3F70]">Absent</p>
        </div>
        {/* Leave */}
        <div className="text-center">
          <div className="text-2xl font-semibold">0</div>
          <p className="text-sm text-[#3B3F70]">Leave</p>
        </div>
      </div>
    </div>
  </div>
);

export default AttendancePanel;
