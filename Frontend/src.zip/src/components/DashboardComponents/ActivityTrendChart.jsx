import React from "react";
import { Bar } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";

// Registering Chart.js components
ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

const ActivityTrendChart = ({ className }) => {
  const data = {
    labels: ['January', 'February', 'March', 'April'],
    datasets: [
      {
        label: 'Activity',
        data: [10, 20, 30, 40],
        backgroundColor: 'rgba(75, 192, 192, 0.6)',
        borderColor: 'rgba(75, 192, 192, 1)',
        borderWidth: 1,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: true,
  };

  return (
    <div className={`w-full mx-auto bg-[#C1C1C1] p-4 rounded-lg shadow-md ${className}`}>
      <h3 className="text-xl font-semibold text-[#3B3F70] mb-4">Activity Trend</h3>
      <Bar data={data} options={options} />
    </div>
  );
};

export default ActivityTrendChart;
