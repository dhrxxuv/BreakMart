import React from "react";

const Snapshots = ({ className }) => (
  <div className={`w-full h-[300px] max-w-[500px] mx-auto bg-[#C1C1C1] p-4 rounded-lg shadow-md ${className}`}>
    <h3 className="text-xl font-semibold text-[#3B3F70] mb-4">Latest Snapshots</h3>
    <div className="flex justify-around">
      <p className="text-[#3B3F70]">Snapshot 1</p>
      <p className="text-[#3B3F70]">Snapshot 2</p>
      <p className="text-[#3B3F70]">Snapshot 3</p>
    </div>
  </div>
);

export default Snapshots;
