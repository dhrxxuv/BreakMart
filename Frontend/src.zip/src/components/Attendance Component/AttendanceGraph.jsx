import React, { useRef, useEffect } from "react";
import { Line } from "react-chartjs-2";
import Chart from "chart.js/auto";  // Import Chart.js to manually handle chart instances

function AttendanceGraph() {
  const chartRef = useRef(null);
  const chartInstanceRef = useRef(null);  // Store the chart instance to manually manage it

  // Chart Data
  const data = {
    labels: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
    datasets: [
      {
        label: "Attendance Percentage",
        data: [80, 85, 90, 70, 75],
        fill: true,
        backgroundColor: "rgba(72, 187, 120, 0.2)",
        borderColor: "rgba(72, 187, 120, 1)",
        tension: 0.4,
      },
    ],
  };

  // Chart Options
  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: true,
        position: "top",
        labels: {
          font: {
            size: 12,
          },
        },
      },
    },
    scales: {
      x: {
        title: {
          display: true,
          text: "Days of the Week",
          font: {
            size: 14,
          },
        },
      },
      y: {
        title: {
          display: true,
          text: "Attendance (%)",
          font: {
            size: 14,
          },
        },
        ticks: {
          stepSize: 10,
          callback: (value) => `${value}%`,
        },
      },
    },
  };

  // Initialize the chart on mount
  useEffect(() => {
    if (chartRef.current && !chartInstanceRef.current) {
      chartInstanceRef.current = new Chart(chartRef.current, {
        type: "line",
        data,
        options,
      });
    }

    // Cleanup the chart on unmount
    return () => {
      if (chartInstanceRef.current) {
        chartInstanceRef.current.destroy();
        chartInstanceRef.current = null;
      }
    };
  }, [data, options]);  // Reinitialize only if data or options change

  return (
    <div className="h-64 p-4 bg-white shadow-md rounded-lg">
      {/* Render chart with the canvas ref */}
      <canvas ref={chartRef}></canvas>
    </div>
  );
}

export default AttendanceGraph;
