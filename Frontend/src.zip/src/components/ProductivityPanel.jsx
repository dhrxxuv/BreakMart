import React from "react";

const ProductivityNavbar = () => {
  return (
    <div>
      <h1>Productivity Panel</h1>
    </div>
  );
};

export default ProductivityNavbar;